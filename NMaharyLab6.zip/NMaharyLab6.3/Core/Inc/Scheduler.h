/*
 * Scheduler.h
 *
 *  Created on: Sep 5, 2023
 *      Author: Natha
 */

#ifndef SCHEDULER_H_
#define SCHEDULER_H_

#include <stdint.h>
#include "Button_Driver.h"

#define LEDTOGGLE	1<<0
#define DELAY	1<<1
#define BUTTON 1<<2
#define TEMP_EVENT	1 << 3
#define GYRO_AXIS	1 << 4
#define REBOOT_CMD	1 << 5
#define START_GAME	1 << 6
#define BEGIN_GAME	1 << 7

uint32_t getScheduledEvents();
void addSchedulerEvent(uint32_t);
void removeSchedulerEvent(uint32_t);


#endif /* SCHEDULER_H_ */
