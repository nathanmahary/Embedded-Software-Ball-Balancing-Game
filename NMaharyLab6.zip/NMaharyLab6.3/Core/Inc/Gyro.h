/*
 * Gyro.h
 *
 *  Created on: Nov 9, 2023
 *      Author: Natha
 */

#ifndef INC_GYRO_H_
#define INC_GYRO_H_

#include <stm32f4xx_hal.h>
#include <stdbool.h>
#include <ErrorHandling.h>

#define I3G4250D_SENSITIVITY_245DPS  ((float)8.75f)         /*!< gyroscope sensitivity with 250 dps full scale [DPS/LSB]  */
#define I3G4250D_SENSITIVITY_500DPS  ((float)17.50f)        /*!< gyroscope sensitivity with 500 dps full scale [DPS/LSB]  */
#define I3G4250D_SENSITIVITY_2000DPS ((float)70.00f)        /*!< gyroscope sensitivity with 2000 dps full scale [DPS/LSB] */

#define dataReg	((float)0.000125) // 800hz


#define WHO_AM_I 	0x0f
#define CTRL_REG1 	0x20
#define CTRL_REG2 	0x21
#define CTRL_REG3 	0x22
#define CTRL_REG4 	0x23
#define CTRL_REG5 	0x24
#define REFERENCE 	0x25
#define OUT_TEMP  	0x26
#define STATUS_REG 	0x27
#define OUT_X_L 	0x28
#define OUT_X_H		0x29
#define OUT_Y_L 	0x2A
#define OUT_Y_H		0x2B
#define OUT_Z_L 	0x2C
#define OUT_Z_H 	0x2D
#define FIFO_CTRL_REG 	0x2E
#define FIFO_SRC_REG 	0x2F
#define INT1_CFG 	0x30
#define INT1_SRC 	0x31
#define INT1_THS_XH 0x32
#define INT1_THS_XL 0x33
#define INT1_THS_YH 0x34
#define INT1_THS_YL 0x35
#define INT1_THS_ZH 0x36
#define INT1_THS_ZL 0x37
#define INT1_DURATION 	0x38

#define PORT	GPIOF
#define PIN_SCK_7	GPIO_PIN_7
#define PIN_MISO_8	GPIO_PIN_8
#define PIN_MOSI_9	GPIO_PIN_9
#define CHIP_SELECT_PORT	GPIOC
#define CHIP_SELECT_PIN		GPIO_PIN_1

#define DELAY1	20000

#define REBOOT (1 << 7)
#define READ (1 << 7)
#define WRITE (0 << 7)
#define POWER (1 << 3)

void Gyro_init(); // done
void Gyro_get(); // done
void Gyro_power(); // done
void Gyro_reboot(); // done
void Gyro_get_temp();
void Gyro_config(); // done
void Gyro_verify_hal();
void Gyro_enable(); // done
void Gyro_disable(); // done
void Gyro_access();

int8_t Get_x_low();
int8_t Get_x_high();
float Get_x_value();
void GyroPosReset();

int8_t Get_y_low();
int8_t Get_y_high();
float Get_y_value();
void GyroPosReset_y();




#endif /* INC_GYRO_H_ */
