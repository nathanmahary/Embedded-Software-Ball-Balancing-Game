/*
 * LED_Driver.h
 *
 *  Created on: Sep 5, 2023
 *      Author: Natha
 */

#include <stdint.h>
// #include <GPIO_Driver.h>

#ifndef LED_DRIVER_H_
#define LED_DRIVER_H_
#define GREENLED 1
#define REDLED 0

void LED_init(uint8_t);
void LED_clock(uint8_t);
void LED_activates(uint8_t);
void LED_deactivates(uint8_t);
void LED_toggle(uint8_t);


#endif /* LED_DRIVER_H_ */
