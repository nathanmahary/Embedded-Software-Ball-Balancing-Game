/*
 * ApplicationCode.h
 *
 *  Created on: Sep 5, 2023
 *      Author: Natha
 */

#ifndef APPLICATIONCODE_H_
#define APPLICATIONCODE_H_
#define MACRO1 6
#define MACRO2 250000

#define RED_SELECT		1
#define GREEN_SELECT	0

#define USE_INTERRUPT_FOR_BUTTON	1

#include <stdint.h>
#include "Led_Driver.h"
#include "Scheduler.h"
#include <stdbool.h>
#include <stm32f4xx_hal.h>
#include <LCD_Driver.h>
#include <RNG.h>
#include <Gyro.h>


void Application_Init();
void Green_Init();
void Green_toggle();
void Green_on();
void Green_off();


void Red_Init();
void Red_toggle();
void Red_on();
void Red_off();

void Both_Init();

void delay(uint32_t);

void Button_Init_App();
void executeButtonPollingRoutine();

void Button_init_interrupt();

void Gyro_init_APP();
void Gyro_get_APP();
void Gyro_config_APP();
void Gyro_power_APP();
void Gyro_reboot_APP();
void Gyro_get_temp_APP();
void Gyro_access_APP();

int16_t Get_x_low_APP();
int16_t Get_x_high_APP();
int16_t Get_x_value_APP();

void RunDemoForLCD(void);
void Ball_Screen_APP(int16_t xval, int16_t yval);

int16_t Get_y_low_APP();
int16_t Get_y_high_APP();
int16_t Get_y_value_APP();


#endif /* APPLICATIONCODE_H_ */
