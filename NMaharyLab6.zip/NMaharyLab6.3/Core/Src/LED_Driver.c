/*
 * LED_Driver.c
 *
 *  Created on: Sep 5, 2023
 *      Author: Natha
 */

#include <LED_Driver.h>
#include <stm32f4xx_hal.h>

static GPIO_InitTypeDef redLED;
static GPIO_InitTypeDef greenLED;



void LED_init(uint8_t led)
{
	switch(led)
	{
		case REDLED:
			__HAL_RCC_GPIOG_CLK_ENABLE();
			redLED.Pin = GPIO_PIN_14;
			redLED.Mode = GPIO_MODE_OUTPUT_PP;
			//redLED. = GPIO_PUSH_PULL;
			redLED.Speed = GPIO_SPEED_FREQ_MEDIUM;
			redLED.Pull = GPIO_NOPULL;
			HAL_GPIO_Init(GPIOG, &redLED);
			break;
		case GREENLED:
			__HAL_RCC_GPIOG_CLK_ENABLE();
			//greenLED.pGPIOx = GPIOG;
			greenLED.Pin = GPIO_PIN_13;
			greenLED.Mode = GPIO_MODE_OUTPUT_PP;
			//greenLED.GPIO_PinConfig.OPType = GPIO_PUSH_PULL;
			greenLED.Speed = GPIO_SPEED_FREQ_MEDIUM;
			greenLED.Pull = GPIO_NOPULL;
			HAL_GPIO_Init(GPIOG, &greenLED);
			break;
		default:
			for(;;);
			break;
	}
}
void LED_toggle(uint8_t led)
{
	switch(led)
	{
		case REDLED:
			HAL_GPIO_TogglePin(GPIOG, redLED.Pin);// changed function call
break;
		case GREENLED:
			HAL_GPIO_TogglePin(GPIOG, greenLED.Pin);// changed function call
			break;
	}
}
void LED_deactivates(uint8_t input)
{
	switch(input)
	{
		case REDLED:
			HAL_GPIO_WritePin(GPIOG, redLED.Pin, GPIO_PIN_RESET);
			break;// changed function call
		case GREENLED:
			HAL_GPIO_WritePin(GPIOG, greenLED.Pin, GPIO_PIN_RESET);
			break;//changed function call

	}
}
void LED_activates(uint8_t led)
{
	switch(led)
	{
		case REDLED:
			HAL_GPIO_WritePin(GPIOG, redLED.Pin, GPIO_PIN_SET);
			break;//changed function call
		case GREENLED:
			HAL_GPIO_WritePin(GPIOG, greenLED.Pin, GPIO_PIN_SET);
			break;// changed function call
	}
}


