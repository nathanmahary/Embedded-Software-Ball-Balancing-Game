/*
 * STM32F429i.h
 *
 *  Created on: Sep 5, 2023
 *      Author: Natha
 */

#ifndef STM32F429I_H_
#define STM32F429I_H_
#include <stdint.h>

#define PERIPHERAL_BASE_ADDR         0x40000000
#define AHB1_BASE_ADDR               0x40020000
#define AHB1_RCC_BASE_ADDR           (AHB1_BASE_ADDR + 0x3800)
#define AHB1_GPIO_BASE_ADDR          (AHB1_BASE_ADDR + 0x1800)
#define GPIOG_1 ((GPIO_RegDef_t*) AHB1_GPIO_BASE_ADDR)
#define RCC_1 ((RCC_RegDef_t*) AHB1_RCC_BASE_ADDR)
#define GPIO_CLOCKENABLE(GPIO_OFFSET)(RCC->RCC_AHB1ENR |= (1 << GPIO_OFFSET))
#define GPIO_CLOCKDISABLE(GPIO_OFFSET)(RCC-> RCC_AHB1ENR &= ~(1 << GPIO_OFFSET))

#define AHB1_GPIOA_BASE_ADDR          (AHB1_BASE_ADDR + 0)

#define GPIOA_OFFSET 0
#define GPIOG_OFFSET 6

#define GPIOA_1 ((GPIO_RegDef_t*) AHB1_GPIOA_BASE_ADDR)


#define ACTIVE 1
#define NON_ACTIVE 0
#define SET 1
#define RESET 0
#define ENABLE SET
#define DISABLE RESET

#define NVIC_ISER0 ((volatile uint32_t*) 0xE000E100)
#define NVIC_ISER1 ((volatile uint32_t*) 0xE000E104)

#define NVIC_ICER0 ((volatile uint32_t*) 0xE000E180)
#define NVIC_ICER1 ((volatile uint32_t*) 0xE000E184)

#define NVIC_ISPR0 ((volatile uint32_t*) 0xE000E200)
#define NVIC_ISPR1 ((volatile uint32_t*) 0xE000E204)

#define NVIC_ICPR0 ((volatile uint32_t*) 0xE000E280)
#define NVIC_ICPR1 ((volatile uint32_t*) 0xE000E284)

#define NVIC_IABR0 ((volatile uint32_t*) 0xE000E300)
#define NVIC_IABR1 ((volatile uint32_t*) 0xE000E304)

#define NVIC_IPR0 ((volatile uint32_t*) 0xE000E400)

#define NVIC_IPR0 ((volatile uint32_t*) 0xE000E400)

#define TIM2_BASE_1	0x40000000
#define TIM5_BASE_1	0x40000C00

#define TIM2_1 ((GPTIMR_RegDef_t*) TIM2_BASE)
#define TIM5_1 ((GPTIMR_RegDef_t*) TIM5_BASE)

#define TIM2_OFFSET	0
#define TIM5_OFFSET	3

#define TIM_CLOCKENABLE(TIM_OFFSET)(RCC->RCC_APB1ENR |= (1 << TIM_OFFSET))
#define TIM_CLOCKDISABLE(TIM_OFFSET)(RCC->RCC_APB1ENR &= ~(1 << TIM_OFFSET))


#define APB2_BASE_ADDR              0x40013800
#define SYSCFG_BASE_ADDR			(APB2_BASE_ADDR + 0x0)
#define EXTI_BASE_ADDR				(APB2_BASE_ADDR + 0x00000400)

#define SYS_CLOCKENABLE()(RCC->RCC_APB2ENR |= (1 << 14))
#define SYS_CLOCKDISABLE()(RCC->RCC_APB2ENR &= ~(1 << 14))

#define EXTI_1 ((EXTI_t*) EXTI_BASE_ADDR)

#define SYSCFG_1 ((SYS_Register_t*) SYSCFG_BASE_ADDR)


#define RNG_BASE_1	0x50060800
#define RNG_OFFSET	6
#define RNG_1 ((RNG_RegDef_t*) RNG_BASE_1)
#define RNG_ClOCKENABLE_1(RNG_OFFSET)(RCC_1->RCC_AHB2ENR |= (1 << RNG_OFFSET))
#define RNG_ClOCKDISABLE_1(RNG_OFFSET)(RCC_1->RCC_AHB2ENR &= ~(1 << RNG_OFFSET))


typedef struct
{
	volatile uint32_t RNG_CR;
	volatile uint32_t RNG_SR;
	volatile uint32_t RNG_DR;
}RNG_RegDef_t;

//typedef struct
//{
//	volatile uint32_t TIM_CR1;
//	volatile uint32_t TIM_CR2;
//	volatile uint32_t TIM_SMCR;
//	volatile uint32_t TIM_DIER;
//	volatile uint32_t TIM_SR;
//	volatile uint32_t TIM_EGR;
//	volatile uint32_t TIM_CCMR1;
//	volatile uint32_t TIM_CCMR2;
//	volatile uint32_t TIM_CCER;
//	volatile uint32_t TIM_CNT;
//	volatile uint32_t TIM_PSC;
//	volatile uint32_t TIM_ARR;
//	volatile uint32_t Reserve1;
//	volatile uint32_t TIM_CCR1;
//	volatile uint32_t TIM_CCR2;
//	volatile uint32_t TIM_CCR3;
//	volatile uint32_t TIM_CCR4;
//	volatile uint32_t Reserve2;
//	volatile uint32_t TIM_DCR;
//	volatile uint32_t TIM_DMAR;
//	volatile uint32_t TIM2_5_OR;
//
//}GPTIMR_RegDef_t;

typedef struct
{
	volatile uint32_t SYSCFG_Memory;
	volatile uint32_t SYSCFG_PMC;
	volatile uint32_t SYSCFG_Exti[4];
	volatile uint32_t SYSCFG_CMP;

}SYS_Register_t;

//typedef struct
//{
//	volatile uint32_t EXTI_imr;
//	volatile uint32_t EXIT_emr;
//	volatile uint32_t EXTI_rtsr;
//	volatile uint32_t ECTI_ftsr;
//	volatile uint32_t EXTI_swier;
//	volatile uint32_t EXTI_pr;
//
//}EXTI_t;

//typedef struct
//	{
//		volatile uint32_t GPIOA_Moder;
//		volatile uint32_t GPIOx_OSPEEDR;
//		volatile uint32_t GPIOx_OTYPER;
//		volatile uint32_t GPIOA_PUPDR;
//		volatile uint32_t GPIOx_IDR;
//		volatile uint32_t GPIOx_ODR;
//		volatile uint32_t GPIOx_BSRR;
//		volatile uint32_t GPIOx_LCKR;
//		volatile uint32_t GPIOx_AFR[2];
//	}GPIO_RegDef_t;

	typedef struct
	{
		volatile uint32_t RCC_CR;
		volatile uint32_t RCC_PLLCFGR;
		volatile uint32_t RCC_CFGR;
		volatile uint32_t RCC_CIR;
		volatile uint32_t RCC_AHB1RSTR;
		volatile uint32_t RCC_AHB2RSTR;
		volatile uint32_t RCC_AHB3RSTR;
		volatile uint32_t Reserve1;
		volatile uint32_t RCC_APB1RS;
		volatile uint32_t RCC_APB2RS;
		volatile uint32_t Reserve23[2];
		volatile uint32_t RCC_AHB1ENR;
		volatile uint32_t RCC_AHB2ENR;
		volatile uint32_t RCC_AHB3ENR;
		volatile uint32_t Reserve4;
		volatile uint32_t RCC_APB1ENR;
		volatile uint32_t RCC_APB2ENR;
		volatile uint32_t Reserve56[2];
		volatile uint32_t RCC_AHB1LP;
		volatile uint32_t RCC_AHB2LP;
		volatile uint32_t RCC_AHB3LP;
		volatile uint32_t Reserve7;
		volatile uint32_t RCC_APB1LP;
		volatile uint32_t RCC_APB2LP;
		volatile uint32_t Reserve89[2];
		volatile uint32_t RCC_BDCR;
		volatile uint32_t RCC_CSR;
		volatile uint32_t Reserve91[2];
		volatile uint32_t RCC_SSCGR;
		volatile uint32_t RCC_PLLI2SCFGR;
		volatile uint32_t RCC_PLLSAICFGR;
		volatile uint32_t RCC_DCKCFGR;

	}RCC_RegDef_t;

#endif /* STM32F429I_H_ */
