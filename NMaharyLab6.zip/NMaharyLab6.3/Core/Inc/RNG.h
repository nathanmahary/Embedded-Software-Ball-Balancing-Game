/*
 * RNG.h
 *
 *  Created on: Dec 1, 2023
 *      Author: Natha
 */

#ifndef INC_RNG_H_
#define INC_RNG_H_


#include <stdint.h>
#include <stdbool.h>
#include <STM32F429i.h>

#define RNGEN	2
#define RNG_USE RNG_1


typedef struct
{
	bool RNG_enable;

}RNG_Config;


typedef struct
{
	RNG_RegDef_t *RNG_reg;
	RNG_Config RNG_details;
}RNG_Handle_t;



void RNG_Init();
void RNG_Clock_Control(RNG_RegDef_t*, uint8_t);
uint32_t RNG_get_ran(RNG_Handle_t* RNG_var);

#endif /* INC_RNG_H_ */
