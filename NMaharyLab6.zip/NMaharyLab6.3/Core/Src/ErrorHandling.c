/*
 * ErrorHandling.c
 *
 *  Created on: Nov 9, 2023
 *      Author: Natha
 */
#include <ErrorHandling.h>

void APPLICATION_ASSERT(bool variable)
{
	if(variable == false)
	{
		while(1)
		{
		}

	}
}
