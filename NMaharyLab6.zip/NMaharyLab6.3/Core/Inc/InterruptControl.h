/*
 * InterruptControl.h
 *
 *  Created on: Oct 3, 2023
 *      Author: Natha
 */

#ifndef INTERRUPTCONTROL_H_
#define INTERRUPTCONTROL_H_
#include <stm32f4xx_hal.h>

// #include "GPIO_Driver.h"

#define EXTI0_IRQ_NUMBER	6


void IRQ_enable(uint8_t);
void IRQ_disable(uint8_t);
void IRQ_clear(uint8_t);
void IRQ_set(uint8_t);

void clear_exti(uint8_t);



#endif /* INTERRUPTCONTROL_H_ */
