/*
 * Scheduler.c
 *
 *  Created on: Sep 5, 2023
 *      Author: Natha
 */

#include <scheduler.h>
#include <stdint.h>

static uint32_t scheduledEvents;

void addSchedulerEvent(uint32_t events)
{
	scheduledEvents |= (events);
}

void removeSchedulerEvent(uint32_t events)
{
	scheduledEvents &= ~(events);
}

uint32_t getScheduledEvents()
{
	return scheduledEvents;
}


