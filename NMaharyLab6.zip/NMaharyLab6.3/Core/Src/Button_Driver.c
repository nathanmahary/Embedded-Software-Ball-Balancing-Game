/*
 * Button_Driver.h
 *
 *  Created on: Sep 26, 2023
 *      Author: Natha
 */


#include "Button_Driver.h"

void Button_Init()
{

	GPIO_InitTypeDef ButtonConfig = {0};
	// ButtonConfig.pGPIOx = BUTTON_PORT;
	ButtonConfig.Pin = GPIO_PIN_0;
	ButtonConfig.Mode = GPIO_MODE_OUTPUT_PP;
	Button_Clock_Enable();
	HAL_GPIO_Init(GPIOA, &ButtonConfig);


}
void Button_Clock_Enable()
{
	//HAL_GPIO_TogglePin(BUTTON_PORT, ENABLE);
	__HAL_RCC_GPIOA_CLK_ENABLE();
}

bool Button_Pressed()
{
	uint8_t temp = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0);
	if(temp == BUTTON_ON)
	{
		return true;
	}
	if(temp == BUTTON_OFF)
	{
		return false;
	}
	return false;
}

void Interrupt_mode()
{
	GPIO_InitTypeDef InterruptConfig = {0};
	// InterruptConfig.pGPIOx = BUTTON_PORT;
	InterruptConfig.Pin = GPIO_PIN_0;
	InterruptConfig.Speed = GPIO_SPEED_FREQ_HIGH;
	InterruptConfig.Mode = GPIO_MODE_IT_RISING;
	InterruptConfig.Pull = GPIO_NOPULL;
	Button_Clock_Enable();
	HAL_GPIO_Init(GPIOA,&InterruptConfig);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);

}
