/*
 * Button_Driver.h
 *
 *  Created on: Sep 26, 2023
 *      Author: Natha
 */

#ifndef BUTTON_DRIVER_H_
#define BUTTON_DRIVER_H_

#include <stdbool.h>
// #include "GPIO_Driver.h"
#include <stm32f4xx_hal.h>
#include <InterruptControl.h>

#define BUTTON_PORT GPIOA
#define BUTTON_PIN 0
#define BUTTON_ON 1
#define BUTTON_OFF 0

void Button_Init();
void Button_Clock_Enable();
bool Button_Pressed();

void Interrupt_mode();



#endif /* BUTTON_DRIVER_H_ */
