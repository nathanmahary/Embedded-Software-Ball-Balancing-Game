/*
 * RNG.c
 *
 *  Created on: Dec 1, 2023
 *      Author: Natha
 */

#include <RNG.h>
#include <stdint.h>
#include <stdbool.h>


void RNG_Init(RNG_Handle_t* RNG_var)
{
	if (RNG_var->RNG_details.RNG_enable)
	{
		RNG_Clock_Control(RNG_USE, ENABLE);
		RNG_var->RNG_reg->RNG_CR |= (0x1 << RNGEN);
	}
	else
	{
		RNG_var->RNG_reg->RNG_CR &= ~(0x1 << RNGEN);
	}
}

void RNG_Clock_Control(RNG_RegDef_t* RNG_var, uint8_t toggle)
{
	if(toggle == 1)
		{
			if(RNG_var == RNG_1)
			{
				RNG_ClOCKENABLE_1(RNG_OFFSET);

			}
		}
		if(toggle == 0)
		{
			if(RNG_var == RNG_1)
			{
				RNG_ClOCKDISABLE_1(RNG_OFFSET);

			}
		}
}

uint32_t RNG_get_ran(RNG_Handle_t* RNG_var)
{
	uint32_t rng_val = RNG_var->RNG_reg->RNG_DR;
	rng_val = rng_val % 160;
	if (rng_val < 0)
	{
		rng_val =rng_val * -1;
	}
	return rng_val;
}
