/*
 * ApplicationCode.c
 *
 *  Created on: Sep 5, 2023
 *      Author: Natha
 */


#include <ApplicationCode.h>
#include <stdint.h>
#include <stdio.h>

static uint8_t LED_Reflect;
static RNG_Handle_t RNG_var;

void Green_Init()
{
	LED_init(GREENLED);
}
void Red_Init()
{
	LED_init(REDLED);
}
void Both_Init()
{
	LED_init(GREENLED);
	LED_init(REDLED);
}
void Green_toggle()
{
	LED_toggle(GREENLED);
}
void Red_toggle()
{
	LED_toggle(REDLED);
}

void Green_on()
{
	LED_activates(GREENLED);
}

void Red_on()
{
	LED_activates(REDLED);
}

void Green_off()
{
	LED_deactivates(GREENLED);
}

void Red_off()
{
	LED_deactivates(REDLED);
}

void delay(uint32_t led)
{
	char Nathan[MACRO1] = {'n','a','t','h','a','n'};
	[[maybe_unused]]char destination[MACRO1];
	for(uint32_t i=0; i < led; i++)
	{
		for(uint32_t j=0; j < MACRO1; j++)
		{
			destination[j]=Nathan[j];
		}
	}
	return;
}

void Application_Init()
{
	Green_Init();
//	// addSchedulerEvent(LEDTOGGLE);
//	addSchedulerEvent(DELAY);
//	Red_Init();
//	LED_Reflect = RED_SELECT;
//	Red_off();
////	Button_Init_App();
//	addSchedulerEvent(LEDTOGGLE);
//	addSchedulerEvent(DELAY);
//
//	addSchedulerEvent(TEMP_EVENT);
//	addSchedulerEvent(GYRO_AXIS);

//	addSchedulerEvent(REBOOT_CMD);


	Gyro_init_APP();

	RNG_var.RNG_reg = RNG_1;
	RNG_var.RNG_details.RNG_enable = ENABLE;
	RNG_Init(&RNG_var);


	LTCD__Init();
	LTCD_Layer_Init(0);
	//RNG
	//Timers

	LCD_Clear(0,LCD_COLOR_WHITE);

	// uint32_t rng_val = RNG_get_ran(&RNG_var);
//	LCD_Draw_Circle_Fill(rng_val,150,20,LCD_COLOR_BLACK);

#if USE_INTERRUPT_FOR_BUTTON == 1
	Button_init_interrupt();


#elif USE_INTERRUPT_FOR_BUTTON == 0
	Button_Init_App();
	addSchedulerEvent(BUTTON);
#endif
//	addSchedulerEvent(DELAY);


}

void Button_Init_App()
{
	Button_Init();
}

void executeButtonPollingRoutine()
{
	if(Button_Pressed() == true)
		{
			if(LED_Reflect == RED_SELECT)
				{
					Red_on();
				}
			if(LED_Reflect == GREEN_SELECT)
				{
					Green_off();
				}
		}

	else
	{
		Red_off();
	}
}
#if USE_INTERRUPT_FOR_BUTTON == 1
void Button_init_interrupt()
{
	Interrupt_mode();
}



void EXTI0_IRQHandler()
{
	IRQ_disable(EXTI0_IRQn);
	addSchedulerEvent(REBOOT_CMD);

	addSchedulerEvent(BEGIN_GAME);
	printf("\n");
	printf("Code has hit BreakPoint\n");
	printf("\n");
		//IRQ_clear(EXTI0_IRQn);

	clear_exti(BUTTON_PIN);
	IRQ_enable(EXTI0_IRQn);
}

#endif

void Gyro_init_APP()
{
	Gyro_init();
}
void Gyro_get_APP()
{
	Gyro_get();
}
void Gyro_config_APP()
{
	Gyro_config();
}
void Gyro_power_APP()
{
	Gyro_power();
}
void Gyro_reboot_APP()
{
	Gyro_reboot();
}
void Gyro_get_temp_APP()
{
	Gyro_get_temp();
}

void Gyro_access_APP()
{
	Gyro_access();
}


int16_t Get_x_value_APP()
{
	return Get_x_value();
}

int16_t Get_y_value_APP()
{
	return Get_y_value();
}


void RunDemoForLCD(void)
{
	QuickDemo();
}

void Ball_Screen_APP(int16_t xval, int16_t yval)
{
	Ball_Screen(xval, yval);
}
