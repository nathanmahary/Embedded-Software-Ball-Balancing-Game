/*
 * InterruptControl.c
 *
 *  Created on: Oct 3, 2023
 *      Author: Natha
 */

#include "InterruptControl.h"

void IRQ_enable(uint8_t IRQ_num)
{
//	if(IRQ_num < 32)
//	{
//		*NVIC_ISER0 |= (1 << IRQ_num);
//	}
//	if(IRQ_num >= 32 && IRQ_num < 64)
//	{
//		*NVIC_ISER1 |= (1 << IRQ_num % 32);
//	}
	HAL_NVIC_EnableIRQ(IRQ_num);
}
void IRQ_disable(uint8_t IRQ_num)
{
//	if(IRQ_num < 32)
//	{
//		*NVIC_ICER0  |= (1 << IRQ_num);
//	}
//	if(IRQ_num >= 32 && IRQ_num < 64)
//	{
//		*NVIC_ICER1  |= (1 << IRQ_num % 32);
//	}
	HAL_NVIC_DisableIRQ(IRQ_num);
}
void IRQ_clear(uint8_t IRQ_num)
{
//	if(IRQ_num < 32)
//	{
//		*NVIC_ICPR0  |= (1 << IRQ_num);
//	}
//	if(IRQ_num >= 32 && IRQ_num < 64)
//	{
//		*NVIC_ICPR1  |= (1 << IRQ_num % 32);
//	}
	HAL_NVIC_ClearPendingIRQ(IRQ_num);
}
void IRQ_set(uint8_t IRQ_num)
{
//	if(IRQ_num < 32)
//	{
//		*NVIC_ISPR0 |= (1 << IRQ_num);
//	}
//	if(IRQ_num >= 32 && IRQ_num < 64)
//	{
//		*NVIC_ISPR1 |= (1 << IRQ_num % 32);
//	}
	HAL_NVIC_SetPendingIRQ(IRQ_num);
}

void clear_exti(uint8_t pin)
{
	EXTI->PR |= (1 << pin);
}



