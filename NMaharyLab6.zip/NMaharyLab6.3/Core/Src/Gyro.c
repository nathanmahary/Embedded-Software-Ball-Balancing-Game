/*
 * Gyro.c
 *
 *  Created on: Nov 13, 2023
 *      Author: Natha
 */
#include <Gyro.h>
#include <stdio.h>

static GPIO_InitTypeDef gyro;
static SPI_HandleTypeDef gyro_spi;
static HAL_StatusTypeDef hal_s;

float x_final_position = 0;
float y_final_position = 0;

void Gyro_init()
{
	__HAL_RCC_GPIOF_CLK_ENABLE();
	gyro.Pin = GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9;
	gyro.Alternate = GPIO_AF5_SPI5;
	gyro.Mode = GPIO_MODE_AF_PP;
	gyro.Speed = GPIO_SPEED_FREQ_LOW;
	gyro.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOF, &gyro);

	__HAL_RCC_GPIOC_CLK_ENABLE();
	gyro.Pin = GPIO_PIN_1;
	gyro.Mode = GPIO_MODE_OUTPUT_OD;
	gyro.Speed = GPIO_SPEED_FREQ_HIGH;
	gyro.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOC, &gyro);

	Gyro_disable();

	gyro_spi.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64;
	gyro_spi.Init.CLKPhase = SPI_PHASE_2EDGE;
	gyro_spi.Init.CLKPolarity = SPI_POLARITY_HIGH;
	gyro_spi.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	gyro_spi.Init.CRCPolynomial = 0;
	gyro_spi.Init.DataSize = SPI_DATASIZE_8BIT;
	gyro_spi.Init.Direction = SPI_DIRECTION_2LINES;
	gyro_spi.Init.FirstBit = SPI_FIRSTBIT_MSB;
	gyro_spi.Init.Mode = SPI_MODE_MASTER;
	gyro_spi.Init.NSS = SPI_NSS_SOFT;
	gyro_spi.Init.TIMode = SPI_TIMODE_DISABLE;

	gyro_spi.Instance = SPI5;

	HAL_SPI_Init(&gyro_spi);
}

void Gyro_get()
{
	uint16_t Rx = 0x00;
	uint8_t to_send = ((READ) | WHO_AM_I);
	Gyro_enable();
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&Rx, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	Rx = ((0xFF00 & Rx) >> 8);
	printf("The Device ID is %d\n", Rx);
}

void Gyro_config()
{
	uint16_t to_send = ((WRITE) | CTRL_REG1) | (0xCF << 8);
	Gyro_enable();
	hal_s = HAL_SPI_Transmit(&gyro_spi, (uint8_t*)&to_send, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	to_send = ((WRITE) | CTRL_REG4) | (0x10 << 8);
	Gyro_enable();
	hal_s = HAL_SPI_Transmit(&gyro_spi, (uint8_t*)&to_send, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	to_send = ((WRITE) | CTRL_REG5) | (0xC0 << 8);
	Gyro_enable();
	hal_s = HAL_SPI_Transmit(&gyro_spi, (uint8_t*)&to_send, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	to_send = ((WRITE) | FIFO_CTRL_REG) | (0x40 << 8);
	Gyro_enable();
	hal_s = HAL_SPI_Transmit(&gyro_spi, (uint8_t*)&to_send, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();


//	to_send = ((0 << 7) | CTRL_REG4) | (4's Data << 8);
//	Gyro_enable();
//	HAL_SPI_Transmit(&gyro_spi, (uint8_t*)&to_send, 2, DELAY);
//	Gyro_disable();


}

void Gyro_verify_hal()
{
	if(hal_s != HAL_OK)
	{
		APPLICATION_ASSERT(false);
	}
}

void Gyro_power()
{
	uint16_t to_send = ((READ) | CTRL_REG1);
	uint16_t dataBack = 0;

	Gyro_enable();
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&dataBack, 2, DELAY1);
	Gyro_disable();

	dataBack = dataBack >> 8;
	dataBack |= POWER;

	to_send = ((WRITE) | CTRL_REG1) | (dataBack << 8);
	Gyro_enable();
	hal_s = HAL_SPI_Transmit(&gyro_spi, (uint8_t*)&to_send, 2, DELAY1);
	Gyro_disable();

}

void Gyro_reboot(){

	uint16_t to_send = ((READ) | CTRL_REG5);
	uint16_t dataBack = 0x00;
	Gyro_enable();
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&dataBack, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	dataBack = dataBack >> 8;
	dataBack |= REBOOT ;


	to_send = ((WRITE) | CTRL_REG5) | (dataBack << 8);
	Gyro_enable();
	hal_s = HAL_SPI_Transmit(&gyro_spi, (uint8_t*)&to_send, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();
}

void Gyro_get_temp()
{
	uint16_t Rx = 0x00;
	uint16_t to_send = ((READ) | OUT_TEMP);


	Gyro_enable();
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&Rx, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	Rx = ((0xFF00 & Rx) >> 8);
	printf("The Temperature %d\n", Rx);

}

void Gyro_enable()
{
	HAL_GPIO_WritePin(CHIP_SELECT_PORT,CHIP_SELECT_PIN,GPIO_PIN_RESET);
}

void Gyro_disable()
{
	HAL_GPIO_WritePin(CHIP_SELECT_PORT,CHIP_SELECT_PIN,GPIO_PIN_SET);
}

void Gyro_access()
{

	//high is upper 8 bits
	//low is lower 8 bits
	uint16_t Rx = 0x00;
	uint16_t to_send;

	Get_x_value();


	Rx = 0x00;
	to_send = ((READ) | OUT_Y_L);
	Gyro_enable();
	while(HAL_GPIO_ReadPin(CHIP_SELECT_PORT, CHIP_SELECT_PIN) != GPIO_PIN_RESET);
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&Rx, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	Rx = ((0xFF00 & Rx) >> 8);
	printf("The Y Low is %d \n", Rx);

	Rx = 0x00;
	to_send = ((READ) | OUT_Y_H);
	Gyro_enable();
	while(HAL_GPIO_ReadPin(CHIP_SELECT_PORT, CHIP_SELECT_PIN) != GPIO_PIN_RESET);
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&Rx, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	Rx = ((0xFF00 & Rx) >> 8);
	printf("The Y High is %d \n", Rx);

	Rx = 0x00;
	to_send = ((READ) | OUT_Z_L);
	Gyro_enable();
	while(HAL_GPIO_ReadPin(CHIP_SELECT_PORT, CHIP_SELECT_PIN) != GPIO_PIN_RESET);
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&Rx, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	Rx = ((0xFF00 & Rx) >> 8);
	printf("The Z Low is %d \n", Rx);

	Rx = 0x00;
	to_send = ((READ) | OUT_Z_H);
	Gyro_enable();
	while(HAL_GPIO_ReadPin(CHIP_SELECT_PORT, CHIP_SELECT_PIN) != GPIO_PIN_RESET);
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&Rx, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	Rx = ((0xFF00 & Rx) >> 8);
	printf("The Z is High %d \n", Rx);


}

int8_t Get_x_low()
{
	uint16_t Rx = 0x00;
	uint16_t to_send = ((READ) | OUT_X_L);
	Gyro_enable();

	while(HAL_GPIO_ReadPin(CHIP_SELECT_PORT, CHIP_SELECT_PIN) != GPIO_PIN_RESET);
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&Rx, 2, DELAY1);
	Gyro_disable();


	Gyro_verify_hal();

	Rx = ((0xFF00 & Rx) >> 8);


	return Rx;
}

int8_t Get_x_high()
{
	int16_t Rx = 0x00;
	int16_t to_send = ((READ) | OUT_X_H);
	Gyro_enable();
	while(HAL_GPIO_ReadPin(CHIP_SELECT_PORT, CHIP_SELECT_PIN) != GPIO_PIN_RESET);
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&Rx, 2, DELAY1);
	Gyro_disable();

	Gyro_verify_hal();

	Rx = ((0xFF00 & Rx) >> 8);

	return Rx;
}

float Get_x_value()
{
	Get_x_low();
	Get_x_high();

	int16_t x_low = Get_x_low();
	int16_t x_high = Get_x_high();

	int16_t x_value = x_high << 8;

	x_value |= x_low;



	float x_velocity = (float)x_value * I3G4250D_SENSITIVITY_500DPS;

	float x_pos = dataReg * x_velocity;


	x_final_position = x_pos + x_final_position;

	return x_final_position;

}

void GyroPosReset()
{
		x_final_position = 0;

}

int8_t Get_y_low()
{
	uint16_t Rx = 0x00;
	uint16_t to_send = ((READ) | OUT_Y_L);
	Gyro_enable();

	while(HAL_GPIO_ReadPin(CHIP_SELECT_PORT, CHIP_SELECT_PIN) != GPIO_PIN_RESET);
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&Rx, 2, DELAY1);
	Gyro_disable();


	Gyro_verify_hal();

	Rx = ((0xFF00 & Rx) >> 8);


	return Rx;
}
int8_t Get_y_high()
{
	uint16_t Rx = 0x00;
	uint16_t to_send = ((READ) | OUT_Y_H);
	Gyro_enable();

	while(HAL_GPIO_ReadPin(CHIP_SELECT_PORT, CHIP_SELECT_PIN) != GPIO_PIN_RESET);
	hal_s = HAL_SPI_TransmitReceive(&gyro_spi, (uint8_t*)&to_send, (uint8_t*)&Rx, 2, DELAY1);
	Gyro_disable();


	Gyro_verify_hal();

	Rx = ((0xFF00 & Rx) >> 8);


	return Rx;
}

float Get_y_value()
{
	Get_y_low();
	Get_y_high();

	int16_t y_low = Get_y_low();
	int16_t y_high = Get_y_high();

	int16_t y_value = y_high << 8;

	y_value |= y_low;



	float y_velocity = (float)y_value * I3G4250D_SENSITIVITY_500DPS;

	float y_pos = dataReg * y_velocity;


	y_final_position = y_pos + y_final_position;

	return y_final_position;

}
void GyroPosReset_y()
{
		x_final_position = 0;

}
